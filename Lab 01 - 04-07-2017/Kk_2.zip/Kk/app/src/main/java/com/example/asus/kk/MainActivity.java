package com.example.asus.kk;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.widget.Toast.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity {

    EditText name;
    Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = (EditText) findViewById(R.id.name);
        btn = (Button) findViewById(R.id.btn1);

    }

    public void showValue(View v){

        if(v.getId() == R.id.btn1 ){
            String a;
            a = name.getText().toString();

            Toast toast = Toast.makeText(getApplicationContext(),"My name is" + a , LENGTH_SHORT);
            toast.show();

        }
    }
}
