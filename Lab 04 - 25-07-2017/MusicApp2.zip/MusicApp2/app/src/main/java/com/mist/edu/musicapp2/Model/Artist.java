package com.mist.edu.musicapp2.Model;

/**
 * Created by Administrator on 8/1/2017.
 */

public class Artist {
    public String artistName;
    public String artistGenre;

    public Artist() {
    }

    public Artist(String artistName, String artistGenre) {
        this.artistName = artistName;
        this.artistGenre = artistGenre;
    }
}
